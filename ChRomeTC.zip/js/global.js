var codeToDirectionMap = new Map();
codeToDirectionMap.set("0", "N");
codeToDirectionMap.set("1", "S");
codeToDirectionMap.set("2", "E");
codeToDirectionMap.set("3", "W");

var directionToCodeMap = new Map();
directionToCodeMap.set("North", 0);
directionToCodeMap.set("South", 1);
directionToCodeMap.set("East", 2);
directionToCodeMap.set("West", 3);