# ChRomeTC/FiReTC
Chrome/Firefox extension for RTC Nomade.

# How to install
Use the [Chrome web store](https://chrome.google.com/webstore/detail/chrometc/ghonlpiinhagjnhgiohnnbajakcfohid) or [Firefox Add-ons Manager](https://addons.mozilla.org/en-US/firefox/addon/firetc/).

You can also clone this repo and add it via the developer mode in Chrome or with `about:debugging` in Firefox.

# Donations
[Donations are welcome!](https://www.paypal.me/jebeaudet)
